from flask import Flask, jsonify, request

app = Flask(__name__)


@app.route('/')
def hello_world():
    return 'Hello World!'


@app.route('/soma', methods=['POST'])
def soma():
    dados = request.get_json()
    num1 = dados.get('num1')
    num2 = dados.get('num2')
    num3 = dados.get('num3')
    soma = num1 + num2 + num3
    return jsonify(soma)


@app.route('/mult', methods=['POST'])
def multi():
    dados = request.get_json()
    num1 = dados.get('num1')
    num2 = dados.get('num2')
    num3 = dados.get('num3')
    multi = num1 * num2 * num3
    return jsonify(multi)


@app.route('/divi', methods=['POST'])
def divi():
    dados = request.get_json()
    num1 = dados.get('num1')
    num2 = dados.get('num2')
    num3 = dados.get('num3')
    divi = (num1 / (num2 / num3))
    if (num1 or num2 or num3 == 0):
        return jsonify('Erro na divisao')
    
    return jsonify(divi)


if __name__ == '__main__':
    app.run()
